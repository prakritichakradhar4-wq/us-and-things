# Us & Things — launch package

This is a zero-cost, static website starter.

## Easiest launch route: GitHub Pages

1. Create a GitHub account at https://github.com/
2. Create a new PUBLIC repository named `us-and-things`.
3. Upload `index.html`.
4. Open the repository's **Settings → Pages**.
5. Under the build/source option, choose **Deploy from a branch**.
6. Select the `main` branch and `/ (root)`, then save.
7. Wait for the Pages deployment. GitHub will show the live site URL in the Pages section.

You can later connect a custom domain, but don't buy one yet if your goal is zero investment.

## Important before accepting real payments

This version does NOT take payments and does not collect user accounts. That is intentional for the first launch.

Launch the free version, test it on phones, and see whether people actually use/share it.

When traffic starts coming in, add a payment provider available to you in Nepal and a secure server-side premium-access system. Do not put secret API keys inside `index.html`.

## First launch checklist

- [ ] Open the live URL on Android
- [ ] Test every button
- [ ] Test Print / Save as PDF
- [ ] Send the link to 5–10 trusted testers
- [ ] Fix broken wording/buttons
- [ ] Make an Instagram/TikTok/Pinterest page
- [ ] Post short demos that send viewers to the website
- [ ] Track visits and which games people actually use
- [ ] Only then build premium packs

## Monetization roadmap

Free → audience → premium digital packs → personalized pages → optional app.

The Rs.5k–10k/day figure should be treated as a target, not a guarantee. For example, 50 sales/day at Rs.199 would be Rs.9,950 gross revenue before any fees/taxes/refunds. Traffic and conversion are the hard part.
